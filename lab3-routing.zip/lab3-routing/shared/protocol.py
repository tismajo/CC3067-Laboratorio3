"""
DUEÑO: EA (Ernesto Ascencio) - Fase 3 (Infraestructura de red)
USADO POR: todos los demás módulos (Dijkstra, Flooding, LSR)

Este archivo define el formato del protocolo acordado en la Fase 0 y las
funciones para construir/parsear paquetes. Es la única fuente de verdad del
formato del mensaje: nadie más debería redefinir el JSON en otro archivo.

Formato acordado (ver enunciado del laboratorio):
{
    "proto": "dijkstra" | "flooding" | "lsr",
    "type": "message" | "echo" | "info" | "hello",
    "from": "<IP origen>",
    "to": "<IP destino>",
    "ttl": <int>,
    "headers": [ {"...": "..."} ],
    "payload": "<contenido dependiente del type>"
}

TODO (EA):
- [ ] Definir constantes para los valores válidos de "proto" y "type".
- [ ] Implementar build_packet(proto, type_, from_, to, ttl, headers, payload) -> dict
- [ ] Implementar serialize(packet: dict) -> str (a JSON)
- [ ] Implementar deserialize(raw: str) -> dict (valida campos obligatorios)
- [ ] Definir función de validación de esquema (¿faltan campos? ¿tipos correctos?)
"""

# TODO: constantes de protocolo (PROTO_DIJKSTRA, PROTO_FLOODING, PROTO_LSR, ...)
# TODO: constantes de tipo de paquete (TYPE_HELLO, TYPE_MESSAGE, TYPE_INFO, ...)


def build_packet(proto, type_, from_, to, ttl, headers=None, payload=None):
    """Construye un paquete (dict) siguiendo el formato acordado."""
    raise NotImplementedError


def serialize(packet: dict) -> str:
    """Convierte un paquete (dict) a un string JSON listo para enviar por socket."""
    raise NotImplementedError


def deserialize(raw: str) -> dict:
    """Convierte un string JSON recibido por socket a un paquete (dict) validado."""
    raise NotImplementedError
